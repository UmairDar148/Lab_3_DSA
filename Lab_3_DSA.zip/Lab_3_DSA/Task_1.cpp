#include "myStack.h"
int main1() {
    int size;
    cout << "Enter the maximum capacity for your stack: ";
    cin >> size;
    myStack<int> stack(size);

    int choice, value;
    do {
        cout << "1. Push\n";
        cout << "2. Pop\n";
        cout << "3. Top\n";
        cout << "4. Check if Empty\n";
        cout << "5. Check if Full\n";
        cout << "6. Display Stack\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter a value to push: ";
            cin >> value;
            stack.push(value);
            break;
        case 2:
            if (!stack.isEmpty()) {
                value = stack.pop();
                cout << "Popped value: " << value << endl;
            }
            else {
                stack.pop();
            }
            break;
        case 3:
            if (!stack.isEmpty()) {
                cout << "Top element is: " << stack.top() << endl;
            }
            else {
                stack.top(); 
            }
            break;
        case 4:
            if (stack.isEmpty()) {
                cout << "Stack is empty\n";
            }
            else {
                cout << "Stack is NOT empty.\n";
            }
            break;
        case 5:
            if (stack.isFull()) {
                cout << "Stack is full\n";
            }
            else {
                cout << "Stack is NOT full\n";
            }
            break;
        case 6:
            stack.display();
            break;
        case 7:
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 7);
    return 0;
}