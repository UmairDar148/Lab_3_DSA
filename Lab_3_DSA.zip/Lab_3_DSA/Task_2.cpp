#include <iostream>
#include "MyStack2.h" 
using namespace std;

int main2() {
    int size;
    cout << "Enter the maximum capacity for your stack: ";
    cin >> size;

    myStack<int> stack(size);

    int choice, value;
    do {
        cout << "1. Push element\n";             
        cout << "2. Pop element\n";              
        cout << "3. Show top element\n";         
        cout << "4. Check if stack is empty\n";  
        cout << "5. Check if stack is full\n";   
        cout << "6. Display stack elements\n";   
        cout << "7. Show minimum element\n";     
        cout << "8. Exit\n";                     
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter an integer value to push: ";
            cin >> value;
            stack.push(value);
            break;
        case 2:
            if (!stack.isEmpty()) {
                value = stack.pop();
                cout << "Popped value: " << value << endl;
            }
            else {
                stack.pop();
            }
            break;
        case 3:
            if (!stack.isEmpty()) {
                cout << "Top element is: " << stack.top() << endl;
            }
            else {
                stack.top();
            }
            break;
        case 4:
            if (stack.isEmpty()) {
                cout << "The stack is currently empty.\n";
            }
            else {
                cout << "The stack is NOT empty.\n";
            }
            break;
        case 5:
            if (stack.isFull()) {
                cout << "The stack is currently full.\n";
            }
            else {
                cout << "The stack is NOT full.\n";
            }
            break;
        case 6:
            stack.display();
            break;
        case 7:
            if (!stack.isEmpty()) {
                cout << "Minimum element is: " << stack.getMin() << endl;
            }
            else {
                stack.getMin();
            }
            break;
        case 8:
            cout << "Exiting the program. Allah Hafiz!\n";
            break;
        default:
            cout << "Invalid choice! Please enter a number between 1 and 8.\n";
        }
    } while (choice != 8);

    return 0;
}