#include "myCarStack.h"
int main3() {
    myCarStack parkingLot;
    int choice;
    string carNum;
    do {
        cout << "\n    Parking Lot Management    \n";
        cout << "1. Park a new car\n";
        cout << "2. Remove a car by number\n";
        cout << "3. View currently parked cars\n";
        cout << "4. Total cars parked\n";
        cout << "5. Search for a car\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter car number or license plate: ";
            cin >> carNum;
            parkingLot.push(carNum);
            break;
        case 2:
            cout << "Enter car number to remove: ";
            cin >> carNum;
            parkingLot.removeCar(carNum);
            break;
        case 3:
            parkingLot.viewParkedCars();
            break;
        case 4:
            cout << "Total cars parked: " << parkingLot.getTotalCars() << "\n";
            break;
        case 5:
            cout << "Enter car number to search: ";
            cin >> carNum;
            if (parkingLot.searchCar(carNum)) {
                cout << "Car " << carNum << " is currently parked here.\n";
            }
            else {
                cout << "Car " << carNum << " is not in the parking lot.\n";
            }
            break;
        case 6:
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 6);
    return 0;
}