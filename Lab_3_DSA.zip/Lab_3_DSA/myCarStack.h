#pragma once
#include <iostream>
#include <string>
using namespace std;
class myCarStack {
private:
    string arr[8];
    int topIndex;
public:
    myCarStack() { topIndex = -1; }
    bool isEmpty() const { return topIndex == -1; }
    bool isFull() const { return topIndex == 7; }
    void push(string carNumber) {
        if (isFull()) {
            cout << "Parking is full.\n";
            return;
        }
        arr[++topIndex] = carNumber;
    }
    string pop() {
        if (isEmpty()) {
            return "";
        }
        return arr[topIndex--];
    }
    string top() const {
        if (isEmpty()) {
            return "";
        }
        return arr[topIndex];
    }

    int getTotalCars() const { return topIndex + 1; }
    void viewParkedCars() const {
        if (isEmpty()) {
            cout << "Parking lot is empty.\n";
            return;
        }
        for (int i = topIndex; i >= 0; i--) {
            cout << arr[i] << "\n";
        }
    }
    bool searchCar(string carNumber) const {
        for (int i = 0; i <= topIndex; i++) {
            if (arr[i] == carNumber) {
                return true;
            }
        }
        return false;
    }
    void removeCar(string carNumber) {
        if (isEmpty()) {
            cout << "Parking lot is empty.\n";
            return;
        }
        if (!searchCar(carNumber)) {
            cout << "Car not found in the parking lot.\n";
            return;
        }
        myCarStack tempStack;
        bool found = false;
        while (!isEmpty()) {
            string currentCar = pop();
            if (currentCar == carNumber) {
                cout << "Car " << carNumber << " has been removed.\n";
                found = true;
                break;
            }
            else { tempStack.push(currentCar);}
        }
        while (!tempStack.isEmpty()) { push(tempStack.pop()); }
    }
};