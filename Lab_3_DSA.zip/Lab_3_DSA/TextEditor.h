#pragma once
#include <iostream>
#include <string>
using namespace std;
class TextEditor {
private:
    string undoStack[100], redoStack[100];
    int undoTop, redoTop;
    string currentText;
public:
    TextEditor() {
        undoTop = -1;
        redoTop = -1;
        currentText = "";
    }
    void typeCharacter(char c) {
        undoStack[++undoTop] = currentText;
        currentText += c;
        redoTop = -1;
    }
    void deleteCharacter() {
        if (currentText.length() > 0) {
            undoStack[++undoTop] = currentText;
            currentText.pop_back();
            redoTop = -1;
        }
    }
    void undo() {
        if (undoTop >= 0) {
            redoStack[++redoTop] = currentText;
            currentText = undoStack[undoTop--];
        }
    }
    void redo() {
        if (redoTop >= 0) {
            undoStack[++undoTop] = currentText;
            currentText = redoStack[redoTop--];
        }
    }
    void displayText() {
        cout << "\nText So Far: " << currentText << "\n";
    }
};