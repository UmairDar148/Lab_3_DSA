#pragma once
#include <iostream>
using namespace std;
template <typename T>
class AbstractStack {
public:
    virtual void push(T value) = 0;
    virtual T pop() = 0;
    virtual T top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
    virtual ~AbstractStack() {}
};

template <typename T>
class myStack : public AbstractStack<T> {
private:
    T* arr;
    int cap, topIndex;
public:
    myStack(int size) {
        cap = size;
        arr = new T[cap];
        topIndex = -1;
    }
    ~myStack() {
        delete[] arr;
    }
    void push(T value) override {
        if (isFull()) {
            cout << "Stack is Full" << value << endl;
            return;
        }
        arr[++topIndex] = value;
    }
    T pop() override {
        if (isEmpty()) {
            cout << "Stack is empty." << endl;
            return T();
        }
        return arr[topIndex--];
    }
    T top() const override {
        if (isEmpty()) {
            cout << "Stack is empty" << endl;
            return T();
        }
        return arr[topIndex];
    }

    bool isEmpty() const override {
        return topIndex == -1;
    }
    bool isFull() const override {
        return topIndex == cap - 1;
    }
    void display() const {
        if (isEmpty()) {
            cout << "Stack is empty." << endl;
            return;
        }
        cout << "Stack: ";
        for (int i = topIndex; i >= 0; i--) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};