#include "TextEditor.h"
using namespace std;
int main() {
    TextEditor editor;
    int choice;
    char c;
    do {
        cout << "\n    Text Editor    \n";
        editor.displayText();
        cout << "1. Type a character\n";
        cout << "2. Delete a character\n";
        cout << "3. Undo\n";
        cout << "4. Redo\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter character: ";
            cin >> c;
            editor.typeCharacter(c);
            break;
        case 2:
            editor.deleteCharacter();
            break;
        case 3:
            editor.undo();
            break;
        case 4:
            editor.redo();
            break;
        case 5:
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 5);
    return 0;
}