#pragma once
#include <iostream>
using namespace std;
template <typename T>
class AbstractStack {
public:
    virtual void push(T value) = 0;
    virtual T pop() = 0;
    virtual T top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
    virtual ~AbstractStack() {}
};
template <typename T>
class myStack : public AbstractStack<T> {
private:
    T* arr;
    T* minArr;
    int cap, topIndex, minTopIndex;
public:
    myStack(int size) {
        cap = size;
        arr = new T[cap];
        minArr = new T[cap];
        topIndex = -1;
        minTopIndex = -1;
    }

    ~myStack() {
        delete[] arr;
        delete[] minArr;
    }
    void push(T value) override {
        if (isFull()) {
            cout << "Stack is Full. Cannot push " << value << endl;
            return;
        }
        arr[++topIndex] = value;

        if (minTopIndex == -1 || value <= minArr[minTopIndex]) {
            minArr[++minTopIndex] = value;
        }
    }
    T pop() override {
        if (isEmpty()) {
            cout << "Stack is empty." << endl;
            return T();
        }
        T poppedValue = arr[topIndex--];

        if (poppedValue == minArr[minTopIndex]) {
            minTopIndex--;
        }
        return poppedValue;
    }
    T top() const override {
        if (isEmpty()) {
            cout << "Stack is empty! No top element." << endl;
            return T();
        }
        return arr[topIndex];
    }
    T getMin() const {
        if (minTopIndex == -1) {
            cout << "Stack is empty! No minimum element." << endl;
            return T();
        }
        return minArr[minTopIndex];
    }
    bool isEmpty() const override {
        return topIndex == -1;
    }
    bool isFull() const override {
        return topIndex == cap - 1;
    }
    void display() const {
        if (isEmpty()) {
            cout << "Stack is empty." << endl;
            return;
        }
        cout << "Stack elements (Top to Bottom): ";
        for (int i = topIndex; i >= 0; i--) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};